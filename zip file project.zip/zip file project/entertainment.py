import fresh_tomatoes
# to import this file which is have html,css code for the site 
import media
#import media file to import fnctions the function 


# want to put names and urls and sentences about the film 
toy_story = media.Movie("toy story", "story of a boy and his toys that come to life ",
                        "https://upload.wikimedia.org/wikipedia/en/1/13/Toy_Story.jpg",
                        "https://www.youtube.com/watch?v=KYz2wyBy3kc")

#print (toy_story.storyline)

avatar = media.Movie("avatar",
                     "a marine on an alien planet",
                     "https://en.wikipedia.org/wiki/File:Avatar-Teaser-Poster.jpg",
                     "https://www.youtube.com/watch?v=d1_JBMrrYw8")

#print (avatar.storyline)
#avatar.show_trailer()

Nemo = media.Movie("Nemo",
                   "searching for s fish",
                   "https://en.wikipedia.org/wiki/File:Finding_Nemo.jpg",
                   "https://www.youtube.com/watch?v=2zLkasScy7A")
                   
#print (Nemo.storyline)
#Nemo.show_trailer()


school_of_rock = media.Movie("school of rock",
                             "using rock music to learn",
                             "https://en.wikipedia.org/wiki/School_of_Rock#/media/File:School_of_Rock_Poster.jpg",
                             "https://www.youtube.com/watch?v=XCwy6lW5Ixc")

ratatouille = media.Movie("ratatouille",
                          "a rat is a chef in pairs",
                          "https://en.wikipedia.org/wiki/Ratatouille_(film)#/media/File:RatatouillePoster.jpg",
                          "https://www.youtube.com/watch?v=3YG4h5GbTqU")

midnight_in_paris = media.Movie("midnight in paris",
                                "going back in time to meet outhors",
                                "https://en.wikipedia.org/wiki/File:Midnight_in_Paris_Poster.jpg",
                                "https://www.youtube.com/watch?v=cXxw6tpM970")
movies =[toy_story, avatar, Nemo, school_of_rock, ratatouille, midnight_in_paris]

fresh_tomatoes.open_movies_page(movies)

#print(media.Movie.__doc__)
# for documentation 
