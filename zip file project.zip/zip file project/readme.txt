Installation:
first you should install python , and you should have any browser such as �Google chrome �. 

Description: 
un zip the folder � 
�to open the code of movie trailer code 
open as movie trailer with any text editor �

�to open the movie trailer website 
open as movie trailer .html 


** to run source code :
** open with python that we installed before 
** open with IDEL 
**open IDEL (python GUI)
** from drop down list click file >open.. >browse to as movie trailer folder >choose the entertainment .py file 
**click open 
**in the entertainment.py code window from drop down menu click RUN,run ,odule . 


Files Descriptions:
fresh_tomatoes.py �which contains the open movies page () function that will take in the list of movies and generate an html file including this content ,producing a website .

media.py �which contains the class movie that holds the instance variables  of which movie object �
entertainment .py  which creats movie objects and put then in movies list �which passed to open_movie_page() function . 
